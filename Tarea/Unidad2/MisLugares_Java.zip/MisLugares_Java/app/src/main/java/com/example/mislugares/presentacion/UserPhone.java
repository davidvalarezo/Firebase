package com.example.mislugares.presentacion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mislugares.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class UserPhone extends AppCompatActivity implements View.OnClickListener {
    private EditText nombre, email;
    private String username, correo;
    private TextInputLayout tilCorreo, tilNombre;
    private FirebaseUser usuario;
    private FirebaseAuth auth = FirebaseAuth.getInstance();
    private FirebaseAuth.AuthStateListener authListener;
    private ViewGroup contenedor;
    private ProgressDialog dialogo;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_phone);

        usuario = auth.getCurrentUser();
        //authListenerEmail();
        nombre = findViewById(R.id.nombre_phone);
        email = findViewById(R.id.email_phone);
        tilCorreo = findViewById(R.id.til_correo_phone);
        tilNombre = findViewById(R.id.til_nombre_phone);
        contenedor = (ViewGroup) findViewById(R.id.contenedor3);

        dialogo = new ProgressDialog(this);
        dialogo.setTitle("Actualizando datos");
        dialogo.setMessage("Por favor espere...");
        mostrarCampos();
        Button actualizarUsuario = findViewById(R.id.btn_user_phone);
        actualizarUsuario.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_user_phone){
            dialogo.show();
            if(verificaCampos()){
                usuario.updateEmail(correo).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()) {
                            dialogo.dismiss();
                            Log.e("MisLugares", "Acción incorrecta: password");
                            mensaje(task.getException().getLocalizedMessage());
                            /*Intent i = new Intent(getBaseContext(), CustomLoginActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                    Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish();*/
                        }else{
                            auth.setLanguageCode("es");
                            auth.getCurrentUser().sendEmailVerification();
                            Toast.makeText(getBaseContext(), "Se ha enviado un correo a "+correo+" para verificación ", Toast.LENGTH_SHORT).show();
                            UserProfileChangeRequest perfil = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(username)
                                    .build();
                            usuario.updateProfile(perfil).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override public void onComplete(@NonNull Task<Void> task) {
                                    if (!task.isSuccessful()) {
                                        dialogo.dismiss();
                                        Log.e("MisLugares", "Acción incorrecta: password");
                                        //mensaje(task.getException().getLocalizedMessage());
                                    }else{

                                        mensaje("Contraseña actualizado con éxito");
                                        Intent i = new Intent(getBaseContext(), MainActivity.class);
                                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                                Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(i);
                                        finish();

                                    }

                                }
                            });

                        }

                    }
                });
            }

        }

    }

    private boolean verificaCampos() {
        correo = email.getText().toString();
        username = nombre.getText().toString();
        tilNombre.setError("");
        tilCorreo.setError("");

        if(username.isEmpty()){
            tilNombre.setError("Introduce un nombre de usuario");
        }else if (correo.isEmpty()) {
            tilCorreo.setError("Introduce un correo");
        } else if (!correo.matches(".+@.+[.].+")) {
            tilCorreo.setError("Correo no válido");
        } else{
            return true;
        }
        return false;



    }

    private void mostrarCampos(){
        correo = usuario.getEmail();
        username = usuario.getDisplayName();
        email.setText(correo);
        nombre.setText(username);


    }

    private void mensaje(String mensaje) {
        Snackbar.make(contenedor, mensaje, Snackbar.LENGTH_LONG).show();
    }

    public void authListenerEmail(){
         authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                //firebaseUser = firebaseAuth.getCurrentUser();
                if (auth.getCurrentUser() != null ) {
                    boolean verificdo = auth.getCurrentUser().isEmailVerified();
                    String msg =  verificdo ? "Correo verificado" : "Correo no ha sido verificado";
                    Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
                    //mensaje(msg);
                } else {
                     //Toast.makeText(getBaseContext(), "Usuario no existe", Toast.LENGTH_SHORT).show();
                    //mensaje("Usuario no existe");
                }
            }
        };
        auth.addAuthStateListener(authListener);
    }

}
