package com.example.mislugares.presentacion;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import static java.lang.Integer.parseInt;

public class Preferencias {
    private static final Preferencias INSTANCIA = new Preferencias();
    private SharedPreferences pref;
    public final static int SELECCION_TODOS =0;
    public final static int SELECCION_MIOS =1;
    public final static int SELECCION_TIPO =2;
    public static Preferencias getInstance() { return INSTANCIA;}
    private Preferencias() {}

    public void inicializa(Context contexto){
        pref = PreferenceManager.getDefaultSharedPreferences(contexto);
    }

    public int criterioSeleccion() {
        return parseInt(pref.getString("seleccion", "0"));
    }

    public String tipoSeleccion() {
        int op = parseInt(pref.getString("tipo_seleccion", "0"));
        String tipo;
        switch (op){
            case 0:
                tipo = "BAR";
                break;
            case 1:
                tipo = "RESTAURANTE";
                break;
            case 2:
                tipo = "COPAS";
                break;
            case 3:
                tipo = "ESPECTACULO";
                break;
            case 4:
                tipo = "HOTEL";
                break;
            case 5:
                tipo = "COMPRAS";
                break;
            case 6:
                tipo = "EDUCACION";
                break;
            case 7:
                tipo = "DEPORTE";
                break;
            case 8:
                tipo = "NATURALEZA";
                break;
            case 9:
                tipo = "GASOLINERA";
                break;
            default:
                tipo = "OTROS";
                break;
        }
        return tipo;
    }

    public String criterioOrdenacion() {
        return (pref.getString("orden", "valoracion"));
    }

    public int maximoMostrar() {
        return parseInt(pref.getString("maximo", "50"));
    }

    public boolean usarFirebaseUI() {
        return (pref.getBoolean("firebaseUI", true));
    }
}
