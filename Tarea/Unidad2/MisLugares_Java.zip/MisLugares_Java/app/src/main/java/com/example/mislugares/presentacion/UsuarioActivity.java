package com.example.mislugares.presentacion;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mislugares.R;

public class UsuarioActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);
    }
}
