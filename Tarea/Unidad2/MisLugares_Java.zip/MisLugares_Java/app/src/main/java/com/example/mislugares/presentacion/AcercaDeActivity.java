package com.example.mislugares.presentacion;

import android.app.Activity;
import android.os.Bundle;

import com.example.mislugares.R;

public class AcercaDeActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acercade);
    }
}
