package com.example.mislugares.presentacion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mislugares.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.auth.UserProfileChangeRequest;

public class ActualizarDatos extends AppCompatActivity implements View.OnClickListener {
    private EditText nombre, email, telefono, contraseña, contraseña_antigua;
    private String username, correo, phone, password, oldpassword;
    private TextInputLayout tilCorreo, tilNombre, tilTelefono, tilContraseña, tilContaseñaAnt;
    private FirebaseUser usuario;
    private FirebaseAuth auth = FirebaseAuth.getInstance();
    private FirebaseAuth.AuthStateListener authListener;
    private ViewGroup contenedor;
    private ProgressDialog dialogo;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actualizar_usuario);

        usuario = auth.getCurrentUser();
        //authListenerEmail();

        nombre = findViewById(R.id.nombre_up);
        email = findViewById(R.id.email_up);
        telefono = findViewById(R.id.telefono_up);
        //telefono.setKeyListener(null);
        telefono.setEnabled(false);
        tilCorreo = findViewById(R.id.til_correo_up);
        tilNombre = findViewById(R.id.til_nombre_up);
        tilTelefono = findViewById(R.id.til_telefono_up);

        contraseña = findViewById(R.id.contraseña_up);
        tilContraseña = findViewById(R.id.til_contraseña_up);
        contraseña_antigua = findViewById(R.id.contraseña_up_vieja);
        tilContaseñaAnt = findViewById(R.id.til_contraseña_up_vieja);

        contraseña_antigua.setEnabled(false);
        contraseña.setEnabled(false);

        contenedor = (ViewGroup) findViewById(R.id.contenedor2);

        dialogo = new ProgressDialog(this);
        dialogo.setTitle("Verificando usuario");
        dialogo.setMessage("Por favor espere...");

        //TextView providers = (TextView) vista.findViewById(R.id.providers);
        //providers.setText(proveedores);
        //Uri urlFoto = usuario.getPhotoUrl();
        //String uid = usuario.getUid();

        if(LoginActivity.isProvider(usuario,"password")){
            contraseña_antigua.setEnabled(true);
            contraseña.setEnabled(true);
        }
        if(LoginActivity.isProvider(usuario,"phone") && !usuario.isEmailVerified()){
            mensaje("Verifica tu correo o inicia sesión con tu cuenta de correo");
        }



        mostrarCampos();
        Button actualizarUsuario = findViewById(R.id.btn_update);
        actualizarUsuario.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_update){
            if(LoginActivity.numeroProveedores == 0){
                mensaje("Acción no permitida para usuario anónimo, debes unificar tu cuenta con otra");
                return;
            }
            dialogo.show();
            if(verificaCampos("nombre")){
                UserProfileChangeRequest perfil = new UserProfileChangeRequest.Builder()
                        .setDisplayName(username)
                        .build();
                usuario.updateProfile(perfil).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()) {
                            dialogo.dismiss();
                            Log.e("MisLugares", "Acción incorrecta: password");
                            mensaje(task.getException().getLocalizedMessage());
                        }else{
                            dialogo.dismiss();
                            mensaje("El nombre se ha actualizado con éxito");

                        }

                    }
                });
            }
            if(verificaCampos("correo")){
                usuario.updateEmail(correo).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()) {
                            dialogo.dismiss();
                            Log.e("MisLugares", "Acción incorrecta: password");
                            mensaje(task.getException().getLocalizedMessage());
                        }else{
                            auth.setLanguageCode("es");
                            auth.getCurrentUser().sendEmailVerification();
                            mensaje("Correo actualizado con éxito. Se te ha enviado un correo para verificación");
                            dialogo.dismiss();
                        }

                    }
                });
            }

            if(verificaCampos("password")){
                authListenerEmail();
                if(!auth.getCurrentUser().isEmailVerified()){
                    mensaje("Unifica tu cuenta con la dirección correo para configurar la contraseña");
                    Toast.makeText(getBaseContext(), "Sin verificación de correo la contraseña no puede ser configurada", Toast.LENGTH_LONG).show();
                    auth.setLanguageCode("es");
                    auth.getCurrentUser().sendEmailVerification();
                    contraseña.setText("");
                    dialogo.dismiss();
                    return;
                }
                oldpassword = contraseña_antigua.getText().toString();
                if(oldpassword.isEmpty() || oldpassword == null){
                    oldpassword = password;
                }
                AuthCredential credential = EmailAuthProvider
                        .getCredential(correo, oldpassword);
                auth.getCurrentUser().reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Log.d("MisLugares", "User re-authenticated.");
                        if (!task.isSuccessful()) {
                            mensaje("No se pudo autentificar el usuario");
                        }else{
                            usuario.updatePassword(password).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override public void onComplete(@NonNull Task<Void> task) {
                                    if (!task.isSuccessful()) {
                                        dialogo.dismiss();
                                        Log.e("MisLugares", "Acción incorrecta: password");
                                        mensaje(task.getException().getLocalizedMessage());
                                    }else{
                                        mensaje("Contraseña se ha actualizado con éxito");
                                        dialogo.dismiss();
                                        Intent i = new Intent(getBaseContext(), MainActivity.class);
                                        /*i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                            Intent.FLAG_ACTIVITY_CLEAR_TASK);*/
                                        startActivity(i);
                                        finish();

                                    }

                                }
                            });
                        }
                    }
                });

            }
            dialogo.dismiss();
        }

    }

    private boolean verificaCampos(String campo) {
        correo = email.getText().toString();
        username = nombre.getText().toString();
        password = contraseña.getText().toString();
        tilNombre.setError("");
        tilCorreo.setError("");
        tilContraseña.setError("");
        if(campo.equals("nombre")){
            if(username.isEmpty()){
                tilNombre.setError("Introduce un nombre de usuario");
                return false;
            }else if(usuario.getDisplayName() != null && usuario.getDisplayName().equals(username)){
                return false;
            }
            return true;
        }
        if(campo.equals("correo")){
            if (correo.isEmpty()) {
                tilCorreo.setError("Introduce un correo");
            } else if (!correo.matches(".+@.+[.].+")) {
                tilCorreo.setError("Correo no válido");
            } else if(usuario.getEmail() != null && usuario.getEmail().equals(correo)){
                return false;
            } else{
                return true;
            }
            return false;
        }
        if(campo.equals("password")){
            if (password.isEmpty()) {
                tilContraseña.setError("Introduce una contraseña");
            } else if (password.length()<6) {
                tilContraseña.setError("Ha de contener al menos 6 caracteres");
            } else if (!password.matches(".*[0-9].*")) {
                tilContraseña.setError("Ha de contener un número");
            } else if (!password.matches(".*[A-Z].*")) {
                tilContraseña.setError("Ha de contener una letra mayúscula");
            } else {
                return true;
            }
            return false;
        }
        return false;
    }

    private void mostrarCampos(){
        correo = usuario.getEmail();
        username = usuario.getDisplayName();
        phone = usuario.getPhoneNumber();

        telefono.setText(phone);
        email.setText(correo);
        nombre.setText(username);

        if(correo == null || correo.isEmpty()){
            contraseña_antigua.setEnabled(false);
            contraseña.setEnabled(false);
        }

        if(LoginActivity.isProvider(usuario,"phone") && !usuario.isEmailVerified()){
            //authListenerEmail();
            mensaje("Verifica tu correo o inicia sesión con tu cuenta de correo");
        }

        if(LoginActivity.numeroProveedores == 0){
            mensaje("Acción no permitida para usuario anónimo, debes unificar tu cuenta con otra");
            return;
        }
    }

    private void mensaje(String mensaje) {
        Snackbar.make(contenedor, mensaje, Snackbar.LENGTH_LONG).show();
    }

    public void authListenerEmail(){
         authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                //firebaseUser = firebaseAuth.getCurrentUser();
                if (auth.getCurrentUser() != null ) {
                    boolean verificdo = auth.getCurrentUser().isEmailVerified();
                    String msg =  verificdo ? "Correo verificado" : "Correo no ha sido verificado";
                    //contraseña_antigua.setEnabled(verificdo);
                    Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
                    //mensaje(msg);
                } else {
                     //Toast.makeText(getBaseContext(), "Usuario no existe", Toast.LENGTH_SHORT).show();
                    //mensaje("Usuario no existe");
                }
            }
        };
        auth.addAuthStateListener(authListener);
    }

    @Override public void onStart(){
        super.onStart();
        mostrarCampos();
    }
}
