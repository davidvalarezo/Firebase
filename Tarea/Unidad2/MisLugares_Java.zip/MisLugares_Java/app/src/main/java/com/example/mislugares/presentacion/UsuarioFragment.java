package com.example.mislugares.presentacion;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.collection.LruCache;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;
import com.example.mislugares.R;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.auth.UserProfileChangeRequest;

import static com.firebase.ui.auth.AuthUI.TAG;

public class UsuarioFragment extends Fragment {
    private FirebaseUser usuario;
    TextView nombre, email, providers, telefono;
    String proveedores ="", nombreUser="", correoUser="", telefonoUser;
    @Override public View onCreateView(LayoutInflater inflador,
                                       ViewGroup contenedor, Bundle savedInstanceState) {
        View vista = inflador.inflate(R.layout.fragment_usuario, contenedor, false);
        usuario = FirebaseAuth.getInstance().getCurrentUser();
        //usuario.reload();
        Log.e("user", "onCreateView: " );


        //Uri urlFoto = usuario.getPhotoUrl();
        nombre = (TextView) vista.findViewById(R.id.nombre);
        email = (TextView) vista.findViewById(R.id.email);
        providers = (TextView) vista.findViewById(R.id.providers);
        telefono = (TextView) vista.findViewById(R.id.telefono);
        mostrarDatos();

        TextView uid = (TextView) vista.findViewById(R.id.uID);
        String uidUser = usuario.getUid();
        uid.setText(uidUser);

        Button cerrarSesion =(Button) vista.findViewById(R.id.btn_cerrar_sesion);
        cerrarSesion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AuthUI.getInstance().signOut(getActivity())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override public void onComplete(@NonNull Task<Void> task) {
                                //Intent i = new Intent(getActivity(),LoginActivity.class);
                                Intent i = new Intent(getActivity(), CustomLoginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                        Intent.FLAG_ACTIVITY_NEW_TASK |
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(i);
                                getActivity().finish();
                            }
                        });
            }
        });

        // Inicialización Volley (Hacer solo una vez en Singleton o Applicaction)
        RequestQueue colaPeticiones = Volley.newRequestQueue(getActivity()
                .getApplicationContext());
                ImageLoader lectorImagenes = new ImageLoader(colaPeticiones,
                new ImageLoader.ImageCache() {
                private final LruCache<String, Bitmap> cache =
                        new LruCache<String, Bitmap>(10);
                public void putBitmap(String url, Bitmap bitmap) {
                    cache.put(url, bitmap);
                }
                public Bitmap getBitmap(String url) {
                    return cache.get(url);
                }
            });
        // Foto de usuario
        Uri urlImagen = usuario.getPhotoUrl();
        if (urlImagen != null) {
            NetworkImageView fotoUsuario = (NetworkImageView) vista.findViewById(R.id.imagen);
            fotoUsuario.setImageUrl(urlImagen.toString(), lectorImagenes);
        }

        Button unirCuenta = (Button) vista.findViewById(R.id.btn_unir_cuenta);
        unirCuenta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),CustomLoginActivity.class);
                i.putExtra("unificar",true);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });

        Button actualizarCuenta = (Button) vista.findViewById(R.id.btn_update);
        actualizarCuenta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),ActualizarDatos.class);
                i.putExtra("actualizar",true);
                startActivity(i);
            }
        });

        return vista;
    }

    public void mostrarDatos(){
        proveedores =""; nombreUser=""; correoUser=""; telefonoUser="";
        if((String)usuario.getDisplayName() != null){
            nombreUser = usuario.getDisplayName();
        }
        if( usuario.getEmail() != null){
            correoUser = usuario.getEmail();
        }
        if(usuario.getPhoneNumber() != null){
            telefonoUser = usuario.getPhoneNumber();
        }
        for (UserInfo proveedor: usuario.getProviderData()) {
            proveedores += proveedor.getProviderId() +", ";
        }
        nombre.setText(nombreUser);
        email.setText(correoUser);
        providers.setText(proveedores);
        telefono.setText(telefonoUser);
    }

    @Override public void onStart(){
        super.onStart();
        mostrarDatos();
    }

}
